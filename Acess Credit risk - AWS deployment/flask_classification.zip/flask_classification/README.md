# Classification ML Model as Flask API

1. First create the ML model by running `python create_model.py`.
2. Then, run `python app.py` to start the server. 

The url to access the app will be provided at the console output.